"""Expert stress tests: recipe construction precedes expert-key access."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json
import numpy as np
from scipy.special import expit,logit
from sklearn.metrics import roc_auc_score,balanced_accuracy_score
from sklearn.linear_model import LogisticRegression
ROOT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')

def known_mean(scores,weights,indices):
    p=scores[:,:,indices];w=(weights[:,:,indices]>.1).astype(float);den=w.sum(-1)
    return np.divide((p*w).sum(-1),den,out=np.full(den.shape,.5),where=den>0)

def _base_recipes(scores,weights,names,expert,include_rank=True):
    result={};used={}
    for i,name in enumerate(names):
        if (weights[expert,:,i]>.01).any():result[name]=scores[:,:,i].copy();used[name]={name:1.}
    index={n:i for i,n in enumerate(names)}
    reports=[n for n in ['steven','pilkwang','lixin','jev_pure','fresh_local_jev'] if n in result]
    # One JEV-family contribution, irrespective of the number of variants.
    p=known_mean(scores,weights,[index[n] for n in ['steven','pilkwang','lixin']]);result['public_three_mean']=p;used['public_three_mean']={n:1/3 for n in ['steven','pilkwang','lixin']}
    jevs=[n for n in ['jev_pure','fresh_local_jev'] if n in result];jev=known_mean(scores,weights,[index[n] for n in jevs]);result['jev_family_mean']=jev;used['jev_family_mean']={n:1/len(jevs) for n in jevs}
    balanced=.25*(scores[:,:,index['steven']]+scores[:,:,index['pilkwang']]+scores[:,:,index['lixin']]+jev)
    result['family_balanced_reports']=balanced;used['family_balanced_reports']={n:.25 for n in ['steven','pilkwang','lixin']};used['family_balanced_reports'].update({n:.25/len(jevs) for n in jevs})
    reportnames=list(result)
    for report in reportnames:
        if report.startswith('mri_'):continue
        for mri in ['mri_best','mri_final16','mri_ensemble']+[n for n in names if n.startswith('mri_member')]:
            if mri not in result:continue
            for fraction in [.25,.5,.75]:
                name=f'{report}__MRI{int(fraction*100)}_{mri}'
                result[name]=np.where(weights[:,:,index[mri]]>.01,(1-fraction)*result[report]+fraction*result[mri],result[report])
                used[name]={k:v*(1-fraction) for k,v in used[report].items()};used[name][mri]=used[name].get(mri,0)+fraction
    weak=np.ones(len(scores),bool);weak[expert]=False
    eligible=[i for i,n in enumerate(names) if n in result]
    if include_rank and eligible and all((weights[weak,:,i]>.01).sum(0).min()>100 for i in eligible):
        ranked=scores.copy()
        for i in eligible:
            for j in range(11):
                reference=np.sort(scores[weak&(weights[:,j,i]>.1),j,i])
                if len(reference)<20:continue
                left=np.searchsorted(reference,scores[:,j,i],side='left');right=np.searchsorted(reference,scores[:,j,i],side='right');values=(left+right)/(2*len(reference));ranked[:,j,i]=np.where(weights[:,j,i]>.1,values,.5)
        alternatives,descriptions=recipes(ranked,weights,names,expert,include_rank=False)
        for name,value in alternatives.items():result['rank__'+name]=value;used['rank__'+name]={'rank__'+k:v for k,v in descriptions[name].items()}
    return result,used

def recipes(scores,weights,names,expert,include_rank=True):
    result,used=_base_recipes(scores,weights,names,expert,include_rank)
    if include_rank and 'decider12_joint'in names:
        keep=[i for i,n in enumerate(names) if n!='decider12_joint'];old,oldused=_base_recipes(scores[:,:,keep],weights[:,:,keep],[names[i] for i in keep],expert,True)
        for name,value in old.items():
            if name.startswith('rank__'):result[name]=value;used[name]=oldused[name]
    return result,used

def score(y,p):
    auc=[float(roc_auc_score(y[:,j],p[:,j])) for j in range(y.shape[1])]
    return dict(macro_AUC=float(np.mean(auc)),per_label_AUC=auc,accuracy_at_half=float(((p>=.5)==y).mean()),macro_balanced_accuracy=float(np.mean([balanced_accuracy_score(y[:,j],p[:,j]>=.5) for j in range(y.shape[1])])),Brier=float(np.square(p-y).mean()))

def platt(p,y):
    out=[]
    for j in range(y.shape[1]):
        if len(np.unique(y[:,j]))<2:out.append({'constant':float((y[:,j].sum()+1)/(len(y)+2))});continue
        x=logit(p[:,j].clip(1e-5,1-1e-5))[:,None];m=LogisticRegression(C=1,max_iter=1000).fit(x,y[:,j]);out.append(dict(coef=float(m.coef_[0,0]),intercept=float(m.intercept_[0])))
    return out
def apply(models,p):
    return np.stack([np.full(len(p),m['constant']) if 'constant'in m else expit(m['coef']*logit(p[:,j].clip(1e-5,1-1e-5))+m['intercept']) for j,m in enumerate(models)],1)
def threshold(p,y):
    confidence=np.maximum(p,1-p).reshape(-1);correct=((p>=.5)==y).reshape(-1);truth=y.reshape(-1);records=[]
    for t in np.unique(confidence):
        a=confidence>=t;coverage=float(a.mean())
        if coverage>=.6:records.append(dict(threshold=float(t),coverage=coverage,accuracy=float(correct[a].mean()),positive_recovery=float((a&correct&(truth==1)).sum()/max(1,(truth==1).sum()))))
    good=[r for r in records if r['accuracy']>=.97 and r['positive_recovery']>=.2]
    best=max(good,key=lambda r:r['coverage']) if good else max(records,key=lambda r:(r['accuracy'],r['positive_recovery'],r['coverage']))
    return {**best,'target_met_on_training_only':bool(good)}

def select(pred,y,fit,composition,keys):
    values=np.array([[fast_auc(y[fit,j],pred[fit,j,k]) for k in range(len(keys))] for j in range(11)])
    per=[max(range(len(keys)),key=lambda k:(values[j,k],-len(composition[keys[k]]),-k)) for j in range(11)]
    glob=max(range(len(keys)),key=lambda k:(values[:,k].mean(),-len(composition[keys[k]]),-k))
    return glob,per
def fast_auc(y,p):
    positive=p[y==1,None];negative=p[y==0][None,:]
    return float(((positive>negative).sum()+.5*(positive==negative).sum())/(positive.size*negative.size))
def selected_scores(pred,glob,per,family):
    globalp=pred[:,:,glob];individual=np.stack([pred[:,j,k] for j,k in enumerate(per)],1)
    return globalp if family=='global' else individual if family=='per_label' else .75*globalp+.25*individual
def confidence_features(p,sources,availability):
    n,c=p.shape;cols=[np.maximum(p,1-p).reshape(-1),np.abs(logit(p.clip(1e-5,1-1e-5))).reshape(-1),(p>=.5).reshape(-1).astype(float),sources.std(-1).reshape(-1),availability.mean(-1).reshape(-1)]
    return np.concatenate([np.stack(cols,1),np.tile(np.eye(c),(n,1))],1)
def risk_policy(conf,correct,truth):
    records=[]
    for t in np.unique(conf):
        a=conf>=t
        if a.mean()>=.6:records.append(dict(threshold=float(t),coverage=float(a.mean()),accuracy=float(correct[a].mean()),positive_recovery=float((a&correct&(truth==1)).sum()/max(1,(truth==1).sum()))))
    good=[r for r in records if r['accuracy']>=.97 and r['positive_recovery']>=.2]
    return {**(max(good,key=lambda r:r['coverage']) if good else max(records,key=lambda r:(r['accuracy'],r['positive_recovery'],r['coverage']))),'training_target_met':bool(good)}

def families(pred,y,folds,sources,availability,composition,keys,ids,out):
    results={};all_raw={}
    for family in ['global','per_label','shrunken']:
        raw=np.zeros_like(y,float);cal=np.zeros_like(raw);confidence=np.zeros_like(raw);accepted=np.zeros_like(y,bool);audits=[]
        for outer in range(5):
            fit=np.flatnonzero(folds!=outer);held=np.flatnonzero(folds==outer);glob,per=select(pred,y,fit,composition,keys);candidate=selected_scores(pred,glob,per,family);raw[held]=candidate[held];maps=platt(candidate[fit],y[fit]);cal[held]=apply(maps,candidate[held]);cross=np.zeros((len(fit),11))
            for f in sorted(set(folds[fit].tolist())):
                tr=fit[folds[fit]!=f];te=fit[folds[fit]==f];g2,p2=select(pred,y,tr,composition,keys);sub=selected_scores(pred,g2,p2,family);cross[folds[fit]==f]=apply(platt(sub[tr],y[tr]),sub[te])
            x=confidence_features(cross,sources[fit],availability[fit]);correct=((cross>=.5)==y[fit]).reshape(-1)
            if len(np.unique(correct))<2:coef=np.zeros(x.shape[1]);intercept=float(logit((correct.sum()+1)/(len(correct)+2)))
            else:
                gate=LogisticRegression(C=.1,max_iter=1000).fit(x,correct);coef=gate.coef_[0];intercept=float(gate.intercept_[0])
            trainconf=expit(x@coef+intercept);policy=risk_policy(trainconf,correct,y[fit].reshape(-1));heldconf=expit(confidence_features(cal[held],sources[held],availability[held])@coef+intercept).reshape(len(held),11);confidence[held]=heldconf;accepted[held]=heldconf>=policy['threshold']
            audits.append(dict(outer_fold=outer,fit_ids=ids[fit].tolist(),held_ids=ids[held].tolist(),global_recipe=keys[glob],per_label_recipes=[keys[k] for k in per],calibration=maps,gate=dict(coef=coef.tolist(),intercept=intercept),policy=policy,outer_answers_used=False))
        directory=out/family;directory.mkdir();np.savez_compressed(directory/'LOCKED_OOF.npz',ids=ids,folds=folds,raw=raw,probabilities=cal,confidence=confidence,accepted=accepted);write(directory/'FIT_AUDIT.json',audits);write(directory/'PREDICTION_LOCK.json',dict(complete=True,sha256=sha(directory/'LOCKED_OOF.npz'),audit_sha256=sha(directory/'FIT_AUDIT.json')))
        correct=(cal>=.5)==y;flat=np.argsort(-confidence.reshape(-1),kind='stable')[:int(np.ceil(.6*y.size))];results[family]=dict(raw=score(y,raw),calibrated=score(y,cal),accepted=dict(cells=int(accepted.sum()),coverage=float(accepted.mean()),accuracy=float(correct[accepted].mean()) if accepted.any() else None,positive_recovery=float((accepted&correct&(y==1)).sum()/max(1,(y==1).sum()))),fixed60_accuracy=float(correct.reshape(-1)[flat].mean()),fixed60_cells=len(flat),fixed60_coverage=float(len(flat)/y.size));all_raw[family]=raw
    glob,per=select(pred,y,np.arange(len(y)),composition,keys);write(out/'DEPLOYMENT_FAMILIES.json',dict(global_recipe=keys[glob],per_label_recipes=[keys[k] for k in per],global_composition=composition[keys[glob]],per_label_composition=[composition[keys[k]] for k in per],shrinkage_weights=[.75,.25],all58_deployment_refit_after_scoring=True))
    return results

def run():
    parser=argparse.ArgumentParser();parser.add_argument('--stage',required=True);parser.add_argument('--strict-mri-oof',action='store_true');parser.add_argument('--frozen-pilot',action='store_true');args=parser.parse_args();out=ROOT/'benchmark'/args.stage;out.mkdir(exist_ok=False)
    with np.load(ROOT/'private/SOURCE_MATRICES.npz') as z:ids=z['ids'].copy();targets=z['targets'].tolist();names=z['source_names'].tolist();p=z['scores'].copy();w=z['confidence'].copy();expert=z['expert_indices'].copy();folds=z['expert_folds'].copy();states=z['assistant_states'].copy()
    if args.strict_mri_oof:
        keep=[i for i,n in enumerate(names) if n!='mri_ensemble' and not n.startswith('mri_member')];p=p[:,:,keep];w=w[:,:,keep];names=[names[i] for i in keep]
    candidates,composition=recipes(p,w,names,expert)
    # During expert-only pilot the new source has no weak CDF yet. Retain every
    # already-frozen baseline rank candidate instead of dropping the control pool.
    if not (ROOT/'WEAK_READY.json').exists() and 'decider12_joint'in names:
        keep=[i for i,n in enumerate(names) if n!='decider12_joint'];base,basecomp=recipes(p[:,:,keep],w[:,:,keep],[names[i] for i in keep],expert)
        for name,value in base.items():
            if name.startswith('rank__'):candidates[name]=value;composition[name]=basecomp[name]
    if args.frozen_pilot:
        with np.load(ROOT/'benchmark/expert-joint-pilot/CANDIDATES_BEFORE_KEY.npz') as locked:pilot_keys=locked['candidate_names'].tolist();pilot_scores=locked['scores'].copy()
        keep=[n for n in pilot_keys if n in candidates];candidates={n:candidates[n] for n in keep};composition={n:composition[n] for n in keep}
        if not args.strict_mri_oof:assert keep==pilot_keys and np.array_equal(np.stack([candidates[n][expert] for n in keep],-1),pilot_scores),'Frozen pilot expert candidate values changed'
    frozen_names=ROOT/'private/FROZEN_CANDIDATE_NAMES.json'
    if frozen_names.exists():
        allowed=read(frozen_names)['candidate_names'];keep=[name for name in allowed if name in candidates]
        if not args.strict_mri_oof:assert keep==allowed
        candidates={n:candidates[n] for n in keep};composition={n:composition[n] for n in keep}
    keys=list(candidates);pred=np.stack([candidates[n][expert] for n in keys],-1)
    np.savez_compressed(out/'CANDIDATES_BEFORE_KEY.npz',ids=ids[expert],targets=np.array(targets),candidate_names=np.array(keys),scores=pred,folds=folds)
    write(out/'CANDIDATE_LOCK.json',dict(complete=True,sha256=sha(out/'CANDIDATES_BEFORE_KEY.npz'),source_matrix_sha256=sha(ROOT/'private/SOURCE_MATRICES.npz'),composition=composition,constructed_without_reading_expert_key=True,created_utc=datetime.now(timezone.utc).isoformat()))
    with np.load(ROOT/'private/EXPERT_KEY.npz') as z:assert np.array_equal(z['ids'],ids[expert]) and z['targets'].tolist()==targets;y=z['labels'].astype(int)
    board={n:score(y,pred[:,:,i]) for i,n in enumerate(keys)};nested=np.zeros_like(y,float);calibrated=np.zeros_like(nested);accepted=np.zeros_like(y,bool);audits=[]
    for f in range(5):
        fit=np.flatnonzero(folds!=f);held=np.flatnonzero(folds==f);selection=[];training=np.zeros((len(fit),11))
        for j in range(11):
            vals=[roc_auc_score(y[fit,j],pred[fit,j,k]) for k in range(len(keys))];best=max(range(len(keys)),key=lambda k:(vals[k],-len(composition[keys[k]]),-k));selection.append(best);nested[held,j]=pred[held,j,best];training[:,j]=pred[fit,j,best]
        maps=platt(training,y[fit]);calibrated[held]=apply(maps,nested[held]);cross=np.zeros_like(training)
        for inner in sorted(set(folds[fit].tolist())):
            tr=folds[fit]!=inner;te=~tr;cross[te]=apply(platt(training[tr],y[fit][tr]),training[te])
        policy=threshold(cross,y[fit]);accepted[held]=np.maximum(calibrated[held],1-calibrated[held])>=policy['threshold']
        audits.append(dict(outer_fold=f,fit_ids=ids[expert[fit]].tolist(),held_ids=ids[expert[held]].tolist(),recipes=[keys[i] for i in selection],recipe_composition=[composition[keys[i]] for i in selection],calibration=maps,policy=policy,new_stage_used_outer_answers=False,public_publisher_prior_selection_exposure_disclosed=True))
    np.savez_compressed(out/'LOCKED_OOF.npz',ids=ids[expert],targets=np.array(targets),folds=folds,raw=nested,probabilities=calibrated,accepted=accepted);write(out/'FIT_AUDIT.json',audits);write(out/'PREDICTION_LOCK.json',dict(complete=True,sha256=sha(out/'LOCKED_OOF.npz'),audit_sha256=sha(out/'FIT_AUDIT.json'),created_utc=datetime.now(timezone.utc).isoformat()))
    correct=(calibrated>=.5)==y;results=dict(raw=score(y,nested),calibrated=score(y,calibrated),accepted=dict(cells=int(accepted.sum()),total_cells=int(y.size),coverage=float(accepted.mean()),accuracy=float(correct[accepted].mean()) if accepted.any() else None,positive_recovery=float((accepted&correct&(y==1)).sum()/max(1,(y==1).sum()))))
    uniform=np.zeros_like(y);results['all_negative_accuracy']=float((uniform==y).mean())
    final=[]
    for j in range(11):
        best=max(range(len(keys)),key=lambda k:(board[keys[k]]['per_label_AUC'][j],-len(composition[keys[k]]),-k));final.append(keys[best])
    write(out/'DEPLOYMENT_RECIPES.json',dict(targets=targets,recipes=final,composition=[composition[n] for n in final],fit_on_all58_after_OOF_scoring=True,all58_fit_not_scored_as_unseen=True,candidate_lock_sha256=sha(out/'CANDIDATE_LOCK.json')))
    extended=families(pred,y,folds,p[expert],(w[expert]>.1).astype(float),composition,keys,ids[expert],out)
    result=dict(complete=True,stage=args.stage,cases=58,targets=targets,source_names=names,strict_mri_oof=args.strict_mri_oof,source_scoreboard=board,nested_fusion=results,extended_families=extended,expert_selected_deployment_recipes=final,public_source_development_exposure=True,same58_familiar_development_not_unseen_or_leaderboard=True,primary_metric='macro ROC-AUC of newly cross-fitted raw fusion',created_utc=datetime.now(timezone.utc).isoformat());write(out/'RESULTS.json',result)
    top=sorted(board,key=lambda n:board[n]['macro_AUC'],reverse=True)[:5];print(json.dumps(dict(stage=args.stage,top5={n:board[n]['macro_AUC'] for n in top},nested=results,extended={n:dict(macro_AUC=v['raw']['macro_AUC'],calibrated_AUC=v['calibrated']['macro_AUC'],accepted=v['accepted'],fixed60_accuracy=v['fixed60_accuracy']) for n,v in extended.items()},selected=final),indent=2))
if __name__=='__main__':run()
