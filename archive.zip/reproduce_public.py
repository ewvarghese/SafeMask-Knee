"""Recompute published expert scores using the official competition train.csv.

No official expert answer key is redistributed with the prediction dataset.
"""
from pathlib import Path
import argparse,csv,json
import numpy as np
from sklearn.metrics import roc_auc_score

def read_rows(path):
    rows=list(csv.DictReader(path.open(encoding='utf-8-sig')))
    assert len(rows)==len({r['StudyInstanceUID'] for r in rows})
    return rows
def run():
    parser=argparse.ArgumentParser();parser.add_argument('--train-csv',type=Path,required=True);parser.add_argument('--dataset',type=Path,default=Path(__file__).resolve().parent);parser.add_argument('--rerun-fusion',action='store_true');args=parser.parse_args();root=args.dataset
    expected=json.loads((root/'benchmark_results.json').read_text());targets=expected['targets'];official={r['StudyInstanceUID']:r for r in read_rows(args.train_csv)};rows=read_rows(root/'expert_oof.csv');assert len(rows)==58
    truth=np.array([[float(official[r['StudyInstanceUID']][t]) for t in targets] for r in rows]);assert ((truth==0)|(truth==1)).all();results={}
    for name,prefix,confidence_prefix in [('auc_raw','auc_raw','confidence'),('auc_calibrated','auc_calibrated','confidence'),('accuracy_calibrated','accuracy_calibrated','accuracy_confidence')]:
        p=np.array([[float(r[prefix+'__'+t]) for t in targets] for r in rows]);confidence=np.array([[float(r[confidence_prefix+'__'+t]) for t in targets] for r in rows]);auc=[float(roc_auc_score(truth[:,j],p[:,j])) for j in range(11)];order=np.argsort(-confidence.reshape(-1),kind='stable')[:int(np.ceil(.6*truth.size))];correct=((p>=.5)==truth).reshape(-1);results[name]=dict(macro_AUC=float(np.mean(auc)),per_label_AUC=auc,full_accuracy=float(correct.mean()),fixed60_accuracy=float(correct[order].mean()),fixed60_cells=len(order),total_cells=truth.size)
    assert np.isclose(results['auc_raw']['macro_AUC'],expected['selected']['auc_score']['raw']['macro_AUC'],atol=1e-12)
    assert np.isclose(results['accuracy_calibrated']['fixed60_accuracy'],expected['selected']['accuracy_score']['fixed60_accuracy'],atol=1e-12)
    print(json.dumps(dict(reproduced=True,cases=58,targets=targets,results=results,scope='Familiar expert development panel; public sources may have used these studies previously.'),indent=2))
    if args.rerun_fusion:
        import tempfile,sys
        import benchmark_core as core
        allrows=read_rows(root/'source_scores.csv');weights={r['StudyInstanceUID']:r for r in read_rows(root/'source_evidence_weights.csv')};provenance=json.loads((root/'source_provenance.json').read_text());names=provenance['matrix_source_names'];metadata={r['StudyInstanceUID']:r for r in read_rows(root/'study_metadata.csv')};ids=np.array([r['StudyInstanceUID'] for r in allrows]);expert=np.array([i for i,s in enumerate(ids) if metadata[s]['official_expert_evaluation_row']=='1']);folds=np.array([int(metadata[s]['expert_fold']) for s in ids[expert]]);p=np.array([[[float(r[n+'__'+t]) for n in names] for t in targets] for r in allrows]);w=np.array([[[float(weights[r['StudyInstanceUID']][n+'__'+t]) for n in names] for t in targets] for r in allrows]);key=np.array([[float(official[s][t]) for t in targets] for s in ids[expert]])
        with tempfile.TemporaryDirectory() as tmp:
            work=Path(tmp);(work/'private').mkdir();(work/'benchmark').mkdir();np.savez_compressed(work/'private/SOURCE_MATRICES.npz',ids=ids,targets=np.array(targets),source_names=np.array(names),scores=p,confidence=w,assistant_states=np.full((len(ids),11),'not_needed'),expert_indices=expert,expert_folds=folds);np.savez_compressed(work/'private/EXPERT_KEY.npz',ids=ids[expert],targets=np.array(targets),labels=key)
            if (root/'candidate_protocol.json').exists():(work/'private/FROZEN_CANDIDATE_NAMES.json').write_bytes((root/'candidate_protocol.json').read_bytes())
            core.ROOT=work;sys.argv=['benchmark_core.py','--stage','reproduced'];core.run();fresh=json.loads((work/'benchmark/reproduced/RESULTS.json').read_text());family=expected['selected']['auc_oriented'];assert np.isclose(fresh['extended_families'][family]['raw']['macro_AUC'],expected['selected']['auc_score']['raw']['macro_AUC'],atol=1e-12);print('Full fusion re-fit reproduced the published AUC-family score.')
            accuracy_family=expected['selected']['accuracy_oriented']
            if accuracy_family.startswith('selective97::'):
                import selective_core
                sys.argv=['selective_core.py','--stage','reproduced'];selective_core.run();comparison=json.loads((work/'benchmark/reproduced/selective97/RESULTS.json').read_text());variant=accuracy_family.split('::',1)[1];assert np.isclose(comparison['families'][variant]['nested_gate']['accuracy'],expected['selected']['accuracy_score']['fixed60_accuracy'],atol=1e-12);print('Full confidence search reproduced the published accuracy-family score.')
if __name__=='__main__':run()
