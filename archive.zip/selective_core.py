"""Study-held confidence selection for the 97%-at-60% development target.

Base predictions stay continuous. Outer expert answers never enter the fitted
classifier, correctness estimator, gate selection, or threshold for that fold.
The same familiar expert panel and historical source exposure still apply.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json
import numpy as np
from scipy.special import expit, logit
from sklearn.ensemble import ExtraTreesClassifier, HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
import benchmark_core as core

CONFIGS = ['margin', 'baseline_logistic', 'label_interactions',
           'family_agreement', 'family_agreement_strong', 'shallow_forest',
           'small_boosting']
FAMILIES = ['global', 'per_label', 'shrunken', 'stack_shared', 'stack_interactions']

def classification_features(sources, weights, names, interactions=False):
    """Joint covariates, not independent votes; correlated MRI members summarized."""
    n, c, _ = sources.shape
    chosen = [i for i, name in enumerate(names) if not name.startswith('mri_member')]
    values = logit(sources[:, :, chosen].clip(.02, .98))
    evidence = weights[:, :, chosen].clip(0, 1)
    known = evidence > .1
    values = np.where(known, values, 0)
    base = np.concatenate([values, evidence], -1).reshape(n*c, -1)
    identity = np.tile(np.eye(c), (n, 1))
    cols = [base, identity]
    if interactions:
        cols.append((values.reshape(n*c, -1)[:, :, None] * identity[:, None, :]).reshape(n*c, -1))
    return np.concatenate(cols, 1)

def fit_classifier(family, sources, weights, names, truth):
    x = classification_features(sources, weights, names, family == 'stack_interactions')
    return make_pipeline(StandardScaler(), LogisticRegression(
        C=.03 if family == 'stack_interactions' else .1, max_iter=2000)).fit(x, truth.reshape(-1))

def classifier_predict(family, model, sources, weights, names):
    x = classification_features(sources, weights, names, family == 'stack_interactions')
    return model.predict_proba(x)[:, list(model.classes_).index(1)].reshape(sources.shape[:2])

def base_fit_predict(predictions, truth, fit, family, composition, keys, sources, weights, names):
    if family.startswith('stack_'):
        model = fit_classifier(family, sources[fit], weights[fit], names, truth[fit])
        value = classifier_predict(family, model, sources, weights, names)
        return value, value
    glob, per = core.select(predictions, truth, fit, composition, keys)
    raw = core.selected_scores(predictions, glob, per, family)
    return raw, core.apply(core.platt(raw[fit], truth[fit]), raw)

def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

def features(probabilities, sources, weights, names, config):
    available = (weights > .1).astype(float)
    baseline = core.confidence_features(probabilities, sources, available)
    if config == 'baseline_logistic':
        return baseline
    n, c = probabilities.shape
    margin = np.abs(2 * probabilities - 1)
    side = (probabilities >= .5).astype(float)
    identity = np.tile(np.eye(c), (n, 1))
    extras = [identity * side.reshape(-1, 1), identity * margin.reshape(-1, 1)]
    if config != 'label_interactions':
        for group in [['steven', 'pilkwang', 'lixin', 'qwen32_report', 'assistant_rules'],
                      ['jev_pure', 'fresh_local_jev', 'typesafe_jev'],
                      [name for name in names if name.startswith('mri_')]]:
            indices = [names.index(name) for name in group if name in names]
            if not indices:
                extras.append(np.zeros((n*c, 6)))
                continue
            score = sources[:, :, indices]
            mask = available[:, :, indices]
            total = mask.sum(-1)
            mean = np.divide((score*mask).sum(-1), total,
                             out=np.full((n, c), .5), where=total > 0)
            variance = np.divide((np.square(score-mean[:, :, None])*mask).sum(-1),
                                 total, out=np.zeros((n, c)), where=total > 0)
            agrees = ((score >= .5) == side[:, :, None]) * mask
            agreement = np.divide(agrees.sum(-1), total,
                                  out=np.full((n, c), .5), where=total > 0)
            extras.append(np.stack([mean, np.sqrt(variance), total/len(indices),
                                    agreement, np.abs(mean-probabilities),
                                    np.abs(2*mean-1)], -1).reshape(n*c, 6))
    return np.concatenate([baseline] + extras, axis=1)

def fit_gate(config, probabilities, sources, weights, names, truth):
    if config == 'margin':
        return None
    x = features(probabilities, sources, weights, names, config)
    correct = ((probabilities >= .5) == truth).reshape(-1).astype(int)
    if len(np.unique(correct)) < 2:
        return float((correct.sum()+1)/(len(correct)+2))
    if config == 'baseline_logistic':
        return LogisticRegression(C=.1, max_iter=1500).fit(x, correct)
    if config in ['label_interactions', 'family_agreement', 'family_agreement_strong']:
        model = make_pipeline(StandardScaler(), LogisticRegression(
            C=.01 if config == 'family_agreement_strong' else .1, max_iter=1500))
    elif config == 'shallow_forest':
        model = ExtraTreesClassifier(n_estimators=128, max_depth=5,
                    min_samples_leaf=16, max_features=.8, n_jobs=12, random_state=97160)
    elif config == 'small_boosting':
        model = HistGradientBoostingClassifier(max_iter=80, max_leaf_nodes=7,
                    min_samples_leaf=24, l2_regularization=20, learning_rate=.05,
                    early_stopping=False, random_state=97160)
    else:
        raise ValueError(config)
    return model.fit(x, correct)

def predict_gate(config, model, probabilities, sources, weights, names):
    if config == 'margin':
        return np.maximum(probabilities, 1-probabilities)
    if isinstance(model, float):
        return np.full_like(probabilities, model)
    x = features(probabilities, sources, weights, names, config)
    return model.predict_proba(x)[:, list(model.classes_).index(1)].reshape(probabilities.shape)

def fixed_metrics(probabilities, confidence, truth, fraction=.6):
    flat = np.argsort(-confidence.reshape(-1), kind='stable')[:int(np.ceil(fraction*truth.size))]
    accepted = np.zeros(truth.size, bool)
    accepted[flat] = True
    accepted = accepted.reshape(truth.shape)
    correct = (probabilities >= .5) == truth
    positives = accepted & (probabilities >= .5)
    return dict(cells=len(flat), total_cells=int(truth.size), coverage=float(accepted.mean()),
                accuracy=float(correct[accepted].mean()), errors=int((~correct & accepted).sum()),
                positive_recovery=float((accepted & correct & (truth == 1)).sum()/max(1, (truth == 1).sum())),
                accepted_predicted_positive=int(positives.sum()),
                accepted_positive_accuracy=float(correct[positives].mean()) if positives.any() else None,
                per_label_accepted_cells=accepted.sum(0).tolist(),
                per_label_errors=(accepted & ~correct).sum(0).tolist())

def base_crossfit(predictions, truth, folds, fit, family, composition, keys, sources, weights, names):
    cross = np.zeros((len(fit), 11))
    for inner in sorted(set(folds[fit].tolist())):
        train = fit[folds[fit] != inner]
        valid = fit[folds[fit] == inner]
        _, calibrated = base_fit_predict(predictions, truth, train, family, composition, keys,
                                          sources, weights, names)
        cross[folds[fit] == inner] = calibrated[valid]
    return cross

def policy_priority(metric):
    # Recovery prevents satisfying the accuracy request by accepting only negatives.
    viable = metric['positive_recovery'] >= .2
    target = viable and metric['accuracy'] >= .97
    return target, viable, metric['accuracy'], metric['positive_recovery']

def choose_joint(options, conservative=False):
    """Only training-group CV scores may be passed here, never outer scores."""
    best=max(options,key=lambda v:(*policy_priority(v['metrics']),-FAMILIES.index(v['family']),-CONFIGS.index(v['gate'])))
    if not conservative:return best
    viable=[v for v in options if v['metrics']['positive_recovery']>=.2]
    if not viable:viable=options
    top=max(v['metrics']['accuracy'] for v in viable)
    shortlist=[v for v in viable if v['metrics']['accuracy']>=top-1/v['metrics']['cells']-1e-12]
    family_cost={'global':1,'per_label':5,'shrunken':3,'stack_shared':2,'stack_interactions':4}
    gate_cost={'margin':0,'baseline_logistic':1,'family_agreement_strong':2,
               'family_agreement':3,'label_interactions':4,'shallow_forest':5,'small_boosting':6}
    return min(shortlist,key=lambda v:(family_cost[v['family']]+gate_cost[v['gate']],
                 -v['metrics']['accuracy'],FAMILIES.index(v['family']),CONFIGS.index(v['gate'])))

def joint_results(out,truth,folds,ids):
    records={};audits={}
    for family in FAMILIES:
        with np.load(out/family/'LOCKED_OOF.npz') as z:records[family]={k:z[k].copy() for k in z.files}
        audits[family]=core.read(out/family/'FIT_AUDIT.json')
    results={}
    for name,conservative in [('joint_nested',False),('conservative_nested',True)]:
        raw=np.zeros_like(truth,float);probabilities=np.zeros_like(raw);confidence=np.zeros_like(raw);choices=[]
        for outer in sorted(set(folds.tolist())):
            options=[]
            for family in FAMILIES:
                audit=next(a for a in audits[family] if a['outer_fold']==outer)
                for gate,metric in audit['inner_gate_metrics'].items():options.append(dict(family=family,gate=gate,metrics=metric))
            chosen=choose_joint(options,conservative);held=folds==outer;data=records[chosen['family']]
            raw[held]=data['raw'][held];probabilities[held]=data['probabilities'][held];confidence[held]=data['confidence_'+chosen['gate']][held]
            choices.append(dict(outer_fold=int(outer),fit_ids=ids[~held].tolist(),held_ids=ids[held].tolist(),
                       chosen=chosen,outer_answers_used_for_any_fitting=False))
        accepted=np.zeros(truth.size,bool);accepted[np.argsort(-confidence.reshape(-1),kind='stable')[:int(np.ceil(.6*truth.size))]]=True;accepted=accepted.reshape(truth.shape)
        folder=out/name;folder.mkdir();np.savez_compressed(folder/'LOCKED_OOF.npz',ids=ids,folds=folds,raw=raw,
                     probabilities=probabilities,confidence=confidence,accepted=accepted)
        write(folder/'FIT_AUDIT.json',choices);fixed=fixed_metrics(probabilities,confidence,truth)
        results[name]=dict(nested_gate=fixed,threshold_policy=None,
              acceptance_mask_is_fixed60_rank_not_threshold_policy=True,
              configs_development_only={},macro_AUC=core.score(truth,raw)['macro_AUC'],
              target_met_point_estimate=fixed['accuracy']>=.97 and fixed['positive_recovery']>=.2,
              classifier_and_gate_selection_exclude_outer_answers=True)
    return results

def evaluate(predictions, truth, folds, sources, weights, names, composition, keys, ids, out):
    results = {}
    for family in FAMILIES:
        raw = np.zeros_like(truth, float)
        probabilities = np.zeros_like(raw)
        configurations = {name: np.zeros_like(raw) for name in CONFIGS}
        nested_confidence = np.zeros_like(raw)
        nested_accepted = np.zeros_like(truth, bool)
        audits = []
        for outer in sorted(set(folds.tolist())):
            fit = np.flatnonzero(folds != outer)
            held = np.flatnonzero(folds == outer)
            candidate, calibrated = base_fit_predict(predictions, truth, fit, family,
                                composition, keys, sources, weights, names)
            raw[held] = candidate[held]
            probabilities[held] = calibrated[held]
            cross = base_crossfit(predictions, truth, folds, fit, family, composition, keys,
                                   sources, weights, names)
            gate_metrics = {}
            gate_crosses = {}
            for config in CONFIGS:
                gate_cross = np.zeros_like(cross)
                for inner in sorted(set(folds[fit].tolist())):
                    train = folds[fit] != inner
                    valid = ~train
                    model = fit_gate(config, cross[train], sources[fit[train]],
                                     weights[fit[train]], names, truth[fit[train]])
                    gate_cross[valid] = predict_gate(config, model, cross[valid],
                                     sources[fit[valid]], weights[fit[valid]], names)
                gate_metrics[config] = fixed_metrics(cross, gate_cross, truth[fit])
                gate_crosses[config] = gate_cross
                model = fit_gate(config, cross, sources[fit], weights[fit], names, truth[fit])
                configurations[config][held] = predict_gate(config, model, probabilities[held],
                                             sources[held], weights[held], names)
            chosen = max(CONFIGS, key=lambda name: (*policy_priority(gate_metrics[name]), -CONFIGS.index(name)))
            nested_confidence[held] = configurations[chosen][held]
            correct = ((cross >= .5) == truth[fit]).reshape(-1)
            policy = core.risk_policy(gate_crosses[chosen].reshape(-1), correct, truth[fit].reshape(-1))
            nested_accepted[held] = nested_confidence[held] >= policy['threshold']
            audits.append(dict(outer_fold=int(outer), fit_ids=ids[fit].tolist(), held_ids=ids[held].tolist(),
                    gate=chosen, inner_gate_metrics=gate_metrics, policy=policy,
                    outer_answers_used_for_any_fitting=False,
                    inner_gate_selection_is_training_only_proxy=True))
        folder = out/family
        folder.mkdir()
        np.savez_compressed(folder/'LOCKED_OOF.npz', ids=ids, folds=folds, raw=raw,
                            probabilities=probabilities, confidence=nested_confidence,
                            accepted=nested_accepted,
                            **{'confidence_'+name:value for name,value in configurations.items()})
        write(folder/'FIT_AUDIT.json', audits)
        fixed = fixed_metrics(probabilities, nested_confidence, truth)
        correct = (probabilities >= .5) == truth
        accepted = dict(cells=int(nested_accepted.sum()), coverage=float(nested_accepted.mean()),
                       accuracy=float(correct[nested_accepted].mean()) if nested_accepted.any() else None)
        results[family] = dict(nested_gate=fixed, threshold_policy=accepted,
            configs_development_only={name:fixed_metrics(probabilities, value, truth)
                                      for name,value in configurations.items()},
            macro_AUC=core.score(truth, raw)['macro_AUC'],
            target_met_point_estimate=fixed['accuracy'] >= .97 and fixed['positive_recovery'] >= .2,
            gate_selection_excludes_outer_answers=True)
    results.update(joint_results(out,truth,folds,ids))
    return results

def run():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', required=True)
    parser.add_argument('--output-name', default='selective97')
    args = parser.parse_args()
    stage = core.ROOT/'benchmark'/args.stage
    assert Path(args.output_name).name == args.output_name
    out = stage/args.output_name
    out.mkdir(exist_ok=False)
    # Freeze the finite confidence-search protocol before this program opens the key.
    write(out/'PROTOCOL_BEFORE_KEY.json',dict(configurations=CONFIGS, families=FAMILIES,
            joint_policies=['best training-CV family+gate','within one training-CV error prefer simpler family+gate'],
            target_accuracy=.97, minimum_coverage=.6, minimum_positive_recovery=.2,
            selection='Inner study-group gate comparisons, nested inside each outer fold.',
            fixed60='Top ceil(.6*638) ranked by held-fold confidence without using held answers.',
            study_folds_kept=True, no_answer_overrides=True,
            code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            created_utc=datetime.now(timezone.utc).isoformat()))
    with np.load(stage/'CANDIDATES_BEFORE_KEY.npz') as z:
        predictions=z['scores'].copy(); keys=z['candidate_names'].tolist()
        ids=z['ids'].copy();folds=z['folds'].copy()
    matrix=stage/'source_snapshot/SOURCE_MATRICES.npz'
    if not matrix.exists():matrix=core.ROOT/'private/SOURCE_MATRICES.npz'
    with np.load(matrix) as z:
        expert=z['expert_indices'];assert np.array_equal(z['ids'][expert],ids)
        sources=z['scores'][expert].copy();weights=z['confidence'][expert].copy();names=z['source_names'].tolist()
    if core.read(stage/'RESULTS.json')['strict_mri_oof']:
        keep=[i for i,n in enumerate(names) if n!='mri_ensemble' and not n.startswith('mri_member')]
        sources=sources[:,:,keep];weights=weights[:,:,keep];names=[names[i] for i in keep]
    composition=core.read(stage/'CANDIDATE_LOCK.json')['composition']
    with np.load(core.ROOT/'private/EXPERT_KEY.npz') as z:
        assert np.array_equal(z['ids'],ids);truth=z['labels'].astype(int)
    results=evaluate(predictions,truth,folds,sources,weights,names,composition,keys,ids,out)
    write(out/'RESULTS.json',dict(complete=True,families=results,cases=58,total_cells=638,
            familiar_development_panel_not_unseen=True,public_source_history_exposure=True,
            protocol_sha256=hashlib.sha256((out/'PROTOCOL_BEFORE_KEY.json').read_bytes()).hexdigest(),
            created_utc=datetime.now(timezone.utc).isoformat()))
    print(json.dumps(results,indent=2))

if __name__=='__main__':run()
